import {fromJS} from 'immutable';
import {APP_CHANGE_MAIN_PATH} from '../actions/commonAction';
import {ORG_TYPE_SCHOOL} from '../constants/CommonConstant';
import {
    APP_LOAD_USER_DATA_SUCCESS, APP_CHANGE_NAV_OPEN_KEYS, APP_CHANGE_SWITCH_MENU_POPOVER,
    APP_CHANGE_SWITCH_SIDER, APP_LOADING_FLAG
} from '../actions/portalMainAction';

export default function hcMain(state = fromJS({
    isNavBar: false, darkTheme: true,
    functions: [], user: {}, organizations: [], schoolList:[], defaultSchoolId: '', notifictionIcon: '', dictMap: {},
    navOpenKeys: [], menuPopoverVisible: false, siderFold: false, loading: false, currPath: ''
}), action) {
    const {type} = action;
    switch (type) {
        case APP_LOAD_USER_DATA_SUCCESS:
            let newState = state.set('functions', fromJS(action.data.menuList));
            newState = newState.set('user', fromJS(action.data.userResDTO));
            let schoolList = fromJS(action.data.schools);
            newState = newState.set('organizations', schoolList);
            schoolList = schoolList.filter(value => value.get('typeCode') === ORG_TYPE_SCHOOL).toSet().toList();
            newState = newState.set('schoolList', schoolList);
            if(action.data.userResDTO.loginOrgType === ORG_TYPE_SCHOOL){
                newState = newState.set('defaultSchoolId', action.data.userResDTO.loginOrgId);
            }else{
                if(!!schoolList && schoolList.size > 0){
                    newState = newState.set('defaultSchoolId', schoolList.getIn([0, 'id']));
                }
            }
            newState = newState.set('notifictionIcon', action.data.notifictionIcon);
            newState = newState.set('dictMap', fromJS(action.data.dictMap));
            return newState;
        case APP_CHANGE_NAV_OPEN_KEYS:
            return state.set('navOpenKeys', fromJS(action.navOpenKeys));
        case APP_CHANGE_SWITCH_MENU_POPOVER:
            return state.set('menuPopoverVisible', !state.get('menuPopoverVisible'));
        case APP_CHANGE_SWITCH_SIDER:
            return state.set('siderFold', !state.get('siderFold'));
        case APP_LOADING_FLAG:
            return state.set('loading', action.flag);
        case APP_CHANGE_MAIN_PATH:
            return state.set('currPath', action.mainPath);
        default:
            return state;
    }
}