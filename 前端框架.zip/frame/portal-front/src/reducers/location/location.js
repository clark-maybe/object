/**
 * Created by lwj on 2017/4/27.
 */
export default function location(state = {path: '/'}, action){
    return action.type === 'LOCATION_CHANGE' ?
    {path: action.path} : state
}