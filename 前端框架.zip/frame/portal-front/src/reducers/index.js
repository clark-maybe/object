import {combineReducers} from 'redux'
import login from './login/login'
import portalMain from './portalMain'
import location from './location/location'

const appReducer = combineReducers({
    login: login,
    portalMain: portalMain,
    location: location
});

const rootReducer = (state, action) => {
    if (action.type === 'RESET') {
        state = {};
    }
    return appReducer(state, action);
};
export default rootReducer;