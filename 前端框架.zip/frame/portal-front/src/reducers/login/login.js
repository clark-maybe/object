/**
 * Created by lwj on 2017/5/15.
 */
import {fromJS} from 'immutable'
import {
    APP_LOGIN_SUCC, APP_LOGIN_FAILARE, APP_LOGIN_RESET
} from '../../actions/login/loginAction'

export default function login(state = fromJS({
    resetTime: new Date().getTime()
}), action) {
    const {type} = action;
    switch (type) {
        case APP_LOGIN_SUCC:
            return state.set('clinicList', fromJS(action.data));
        case APP_LOGIN_FAILARE:
            return state.set('errorMessage', action.errorMessage).set('resetTime', new Date().getTime());
        case APP_LOGIN_RESET:
            return state.set('resetTime', new Date().getTime());
        default:
            return state;
    }
}