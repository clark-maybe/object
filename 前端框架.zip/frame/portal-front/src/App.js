/* @flow */
import React from 'react';
import {Route, Router} from 'react-router-dom'
import {connect} from 'react-redux'
import history from './history'
import './components/layout/common.less'
import Login from './containers/login/Login';
import PortalMain from './containers/PortalMain';

class App extends React.Component {
    render() {
        return (
            <Router history={history}>
                <div style={{height:'100%', width:'100%'}}>
                    <Route exact path="/" component={Login}/>
                    <Route path="/hc" component={PortalMain}/>
                </div>
            </Router>
        )
    }
}


const mapStateToAppProps = (state, ownProps) => {
    let portalMain = state.portalMain;
    return {
        isNavBar: portalMain.get('isNavBar')
    }
};
export default connect(mapStateToAppProps)(App);
