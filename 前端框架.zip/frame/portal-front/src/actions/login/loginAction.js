/**
 * Created by lwj on 2017/5/15.
 */
import {Modal} from 'antd';
import {REQUEST_WAR_NAME} from '../../constants/CommonConstant';
import {fetchData} from '../../utils/fetchService'
import history from '../../history'
import {disconnectEventSocket} from '../eventAction'

export const  APP_LOGIN_SUCC = 'APP_LOGIN_SUCC';
export const  APP_LOGIN_RESET = 'APP_LOGIN_RESET';
export const  APP_LOGIN_FAILARE = 'APP_LOGIN_FAILARE';

export function login(user) {
    return (dispatch) => {
        var str = [];
        for (var p in user) {
            str.push(encodeURIComponent(p) + '=' + encodeURIComponent(user[p]));
        }
        fetchData(REQUEST_WAR_NAME + '/login', {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            body: str.join('&')
        }).then(response => {
            if (!response.flag) {
                // 登录失败，提示登录失败
                dispatch(loginFailure('登录失败：' + response.message));
                return;
            }
            dispatch(querySchoolList());
        }).catch(function (e) {
            dispatch(loginFailure(e));
        });
    }
}
export function querySchoolList() {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/login/querySchoolList.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch(loginSucc(response.data));
                } else {
                    Modal.warning({
                        title: '获取用户门诊出错',
                        content: '出错信息:' + response.message,
                        onOk() {
                            history.replace('/');
                        }
                    })
                }
            }
        );
    }
}
export function loginSucc(data) {
    return {
        type: APP_LOGIN_SUCC,
        data: data
    }
}

export function reset() {
    return {
        type: APP_LOGIN_RESET
    }
}
export function logout(){
    return (dispatch, getState) => {
        fetch(REQUEST_WAR_NAME + '/logout', {
            credentials: 'include',
            method: 'POST'
        }).then(response => {
            if (!response.ok) {
                Modal.warning({
                    title:'登出系统失败',
                    content:'登出系统失败',
                    onOk() {
                        history.replace('/');
                    }
                });
            }
            history.replace('/');
            dispatch(disconnectEventSocket());
        }).catch(function () {
            history.replace('/');
            dispatch(disconnectEventSocket());
        });
    }
}
export function loginFailure(errorMessage){
    return {
        type: APP_LOGIN_FAILARE,
        errorMessage: errorMessage
    }
}

export function clearSockets(){
    return (dispatch, getState) => {
        dispatch(disconnectEventSocket());
    }
}