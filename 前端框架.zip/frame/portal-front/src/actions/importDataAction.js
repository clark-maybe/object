/**
 * Created by lwj on 2017/7/27.
 */

import {Modal} from 'antd'
import {REQUEST_WAR_NAME} from '../constants/CommonConstant';
import {fetchData} from '../utils/fetchService'

export function importEmr(params){
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/data/importEmr.do',  {body: JSON.stringify(params)}).then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                } else {
                    Modal.warning({
                        title: '导入病历出错',
                        content: '出错信息:' + response.message,
                        onOk() {

                        }
                    })
                }
            }
        );
    }
}

export function syncUserId(){
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/data/syncUserId.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                } else {
                    Modal.warning({
                        title: '查询门诊错误',
                        content: '出错信息:' + response.message,
                        onOk() {

                        }
                    })
                }
            }
        );
    }
}

export function modifyCustomerPinyin(){
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/data/modifyCustomerPinyin.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                } else {
                    Modal.warning({
                        title: '生成患者拼音出错',
                        content: '出错信息:' + response.message,
                        onOk() {

                        }
                    })
                }
            }
        );
    }
}

export function importAngelOrder(){
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/data/importAngelOrder.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                } else {
                    Modal.warning({
                        title: '导入小天使订单数据失败',
                        content: '出错信息:' + response.message,
                        onOk() {

                        }
                    })
                }
            }
        );
    }
}

export function importAsmOrder(){
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/data/importAsmOrder.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                } else {
                    Modal.warning({
                        title: '导入爱圣美订单数据失败',
                        content: '出错信息:' + response.message,
                        onOk() {

                        }
                    })
                }
            }
        );
    }
}