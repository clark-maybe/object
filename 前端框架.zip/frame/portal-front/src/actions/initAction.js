import {fetchData} from '../utils/fetchService';
import {REQUEST_WAR_NAME} from '../constants/CommonConstant';
import {Modal} from 'antd';

/**
 * 学员明细初始化action
 */
export function studentDetailInit(params, type) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/hcCustomer/detail.do', {body: JSON.stringify(params)}).then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch({
                        type: type,
                        data: response.data
                    });
                } else {
                    Modal.warning({
                        title: '学员明细初始化错误',
                        content: '出错信息:' + response.message
                    });
                }
            }
        );
    }
}

/**
 * 来源初始化action
 */
export function originInit(type) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/baseInit/init.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch({
                        type: type,
                        data: response.data
                    });
                } else {
                    Modal.warning({
                        title: '来源初始化错误',
                        content: '出错信息:' + response.message
                    });
                }
            }
        );
    }
}

/**
 * 商品初始化action
 */
export function commodityInit(type) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/order/init.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch({
                        type: type,
                        data: response.data
                    });
                } else {
                    Modal.warning({
                        title: '商品初始化错误',
                        content: '出错信息:' + response.message
                    });
                }
            }
        );
    }
}

/**
 * 教材初始化action
 */
export function textBookInit(type) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/saleCommodity/selectAllCommodity.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch({
                        type: type,
                        data: response.data
                    });
                } else {
                    Modal.warning({
                        title: '教材初始化错误',
                        content: '出错信息:' + response.message
                    });
                }
            }
        );
    }
}

/**
 * 学员定金初始化action
 */
export function studentDepositInit(params, type) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/deposit/queryStuDeposit.do', {body: JSON.stringify(params)}).then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch({
                        type: type,
                        data: response.data
                    });
                } else {
                    Modal.warning({
                        title: '学员定金初始化错误',
                        content: '出错信息:' + response.message
                    });
                }
            }
        );
    }
}

/**
 * 学员报名初始化action
 */
export function studentEnrollInit(params, type) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/order/queryStuOrder.do', {body: JSON.stringify(params)}).then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch({
                        type: type,
                        data: response.data
                    });
                } else {
                    Modal.warning({
                        title: '学员报名初始化错误',
                        content: '出错信息:' + response.message
                    });
                }
            }
        );
    }
}

/**
 * 学员发票初始化action
 */
export function studentInvoiceInit(params, type) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/saleInvoice/queryEffective.do', {body: JSON.stringify(params)}).then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch({
                        type: type,
                        data: response.data
                    });
                } else {
                    Modal.warning({
                        title: '学员发票初始化错误',
                        content: '出错信息:' + response.message
                    });
                }
            }
        );
    }
}

/**
 * 合作方初始化action
 */
export function partnerInit(type) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/partner/init.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch({
                        type: type,
                        data: response.data
                    });
                } else {
                    Modal.warning({
                        title: '学员报名初始化错误',
                        content: '出错信息:' + response.message
                    });
                }
            }
        );
    }
}

/**
 * 查询一级分组
 */
export function initFirstGroup(type) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/group/queryAllFirst.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch({
                        type: type,
                        data: response.data
                    });
                } else {
                    Modal.warning({
                        title: '学员报名初始化错误',
                        content: '出错信息:' + response.message
                    });
                }
            }
        );
    }
}

/**
 * 查询二级分组
 * @param type
 * @returns {function(*)}
 */
export function initSecondGroup(type) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/group/queryAllSecond.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch({
                        type: type,
                        data: response.data
                    });
                } else {
                    Modal.warning({
                        title: '学员报名初始化错误',
                        content: '出错信息:' + response.message
                    });
                }
            }
        );
    }
}

//初始化机构 人员信息
export function initOrgAndUser(type) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/hcWorkTask/init.do').then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch({
                        type: type,
                        data: response.data
                    });
                } else {
                    Modal.warning({
                        title: '初始化错误',
                        content: '出错信息:' + response.message,
                        onOk() {
                        }
                    })
                }
            }
        );
    }
}