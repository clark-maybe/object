/**
 * Created by hanzhengqiang on 2017/5/18.
 */
import {Modal} from 'antd'
import {REQUEST_WAR_NAME} from '../constants/CommonConstant';
import {fetchData} from '../utils/fetchService'

export const APP_CHANGE_MAIN_PATH = 'APP_CHANGE_MAIN_PATH';

export function changeMainPath(mainPath) {
    return {
        type: APP_CHANGE_MAIN_PATH,
        mainPath: mainPath
    }
}
/**
 * 加载状态处理
 * @param isLoading
 * @returns {{type: string, isLoading: *}}
 */
export function loadingNoPageSucc(isLoading, dispatchType) {
    return {
        type: dispatchType,
        isLoading: isLoading
    }
}
/**
 * 加载状态处理
 */
export function loadingSucc(isLoading, current, pageSize, dispatchType) {
    return {
        type: dispatchType,
        isLoading: isLoading,
        current: current,
        pageSize: pageSize
    }
}
/**
 * 修改查询表单数据
 */
export function changeSearchFormData(fields, dispatchType) {
    return {
        type: dispatchType,
        fields: fields
    }
}
/**
 * 重置查询表单数据
 */
export function resetSearchFormData(dispatchType) {
    return {
        type: dispatchType
    }
}
/**
 * 清空选项
 */
export function emptyOption(sourceTag, dispatchType) {
    return {
        type: dispatchType,
        sourceTag: sourceTag
    }
}
/**
 * 排序
 * @param list
 * @param sorter
 */
export function sortDataList(list, sorter, sortType, dispatchType) {
    return {
        type: dispatchType,
        list: list,
        sorter: sorter,
        sortType: sortType
    }
}

/**
 * 改变选中的记录
 * @returns {{type: string}}
 */
export function changeSelectedRowKeys(selectedRowKeys, dispatchType) {
    return {
        type: dispatchType,
        selectedRowKeys: selectedRowKeys
    }
}
/**
 * 改变选中的TAB
 * @returns {{type: string}}
 */
export function changeActiveKey(activeKey, dispatchType) {
    return {
        type: dispatchType,
        activeKey: activeKey
    }
}

/**
 * 查询连锁
 * @returns {function()}
 */
export function selectChain(reqParams, changeFormTag, succDispatchType, errorDispatchType) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/memberSystem/selectChainByCity.do',
            {body: JSON.stringify(reqParams)}).then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch(selectChainSucc(response.data, changeFormTag, succDispatchType));
                } else {
                    Modal.warning({
                        title: '查询连锁错误',
                        content: '出错信息:' + response.message,
                        onOk() {
                            dispatch({type: errorDispatchType});
                        }
                    })
                }
            }
        );
    }
}
export function selectChainSucc(data, changeFormTag, succDispatchType) {
    return {
        type: succDispatchType,
        changeFormTag: changeFormTag,
        data: data
    }
}
/**
 * 查询门诊
 * @returns {function()}
 */
export function selectClinic(reqParams, succDispatchType, errorDispatchType) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/clinic/selectClinicByChainAndArea.do',
            {body: JSON.stringify(reqParams)}).then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch(selectClinicSucc(response.data, succDispatchType));
                } else {
                    Modal.warning({
                        title: '查询门诊错误',
                        content: '出错信息:' + response.message,
                        onOk() {
                            dispatch({type: errorDispatchType});
                        }
                    })
                }
            }
        );
    }
}
export function selectClinicSucc(data, succDispatchType) {
    return {
        type: succDispatchType,
        data: data
    }
}

/**
 * 报表查询初始化
 * @param reqParams = [{queryId:String,params:Map}]
 * @returns {function()}
 */
export function initReport(reqParams, succDispatchType, errorDispatchType) {
    return (dispatch) => {
        if (!!reqParams) {
            fetchData(REQUEST_WAR_NAME + '/hismdp/batchQuery.do', {body: JSON.stringify(reqParams)}).then(
                response => {
                    let flag = response.flag;
                    if (typeof flag !== 'undefined' && flag === 1) {
                        dispatch(initReportSucc(response.data, succDispatchType));
                    } else {
                        Modal.warning({
                            title: '错误',
                            content: '出错信息:' + response.message,
                            onOk() {
                                dispatch({type: errorDispatchType});
                            }
                        })
                    }
                }
            );
        } else {
            dispatch(initReportSucc([], succDispatchType));
        }
    }
}
export function initReportSucc(data, succDispatchType) {
    return {
        type: succDispatchType,
        data: data
    }
}
/**
 * 报表根据条件查询数据
 * @param tag--查询数据的类型
 * @param reqParams = {queryId:String,params:Map}
 * @returns {function()}
 */
export function queryReportCondition(sourseTag, reqParams, dispatchType, errorDispatchType) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/hismdp/query.do', {body: JSON.stringify(reqParams)}).then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    dispatch(queryReportConditionSucc(sourseTag, response.data, dispatchType));
                } else {
                    Modal.warning({
                        title: '错误',
                        content: '出错信息:' + response.message,
                        onOk() {
                            dispatch({type: errorDispatchType});
                        }
                    })
                }
            }
        );
    }
}
export function queryReportConditionSucc(sourseTag, data, dispatchType) {
    return {
        type: dispatchType,
        sourseTag: sourseTag,
        data: data
    }
}