import {Modal, notification} from 'antd';
import {REQUEST_WAR_NAME} from '../constants/CommonConstant';
import {setButtonMap} from '../constants/authenticate';
import {fetchData} from '../utils/fetchService';
import history from '../history';
import {connectEventSocket} from './eventAction';

export const  APP_LOAD_USER_DATA_SUCCESS = 'APP_LOAD_USER_DATA_SUCCESS';
export const  APP_CHANGE_NAV_OPEN_KEYS = 'APP_CHANGE_NAV_OPEN_KEYS';
export const  APP_CHANGE_SWITCH_MENU_POPOVER = 'APP_CHANGE_SWITCH_MENU_POPOVER';
export const  APP_CHANGE_SWITCH_SIDER = 'APP_CHANGE_SWITCH_SIDER';
export const  APP_RESET_STATE = 'APP_RESET_STATE';
export const  APP_LOADING_FLAG = 'APP_LOADING_FLAG';

export function loadUserData(currPath, params) {
    return (dispatch) => {
        fetchData(REQUEST_WAR_NAME + '/login/loginInfo.do',{body: JSON.stringify(params)}).then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    setButtonMap(response.data.buttonMap);
                    dispatch(connectEventSocket(response.data.userResDTO));
                    dispatch({
                        type: APP_LOAD_USER_DATA_SUCCESS,
                        data: response.data
                    });
                    if (currPath === '/hc') {
                        if (response.data.menuList.length > 0) {
                            let path = response.data.menuList[0].funcAction;
                            if(!!response.data.menuList[0].children && response.data.menuList[0].children.length > 0){
                                path = response.data.menuList[0].children[0].funcAction;
                            }
                            history.replace(path);
                        }
                    }
                } else {
                    Modal.warning({
                        title: '获取用户数据出错',
                        content: '出错信息:' + response.message,
                        onOk() {
                            history.replace('/');
                        }
                    });
                }
            }
        );
    }
}

export function changeNavOpenKeys(navOpenKeys){
    return {
        type: APP_CHANGE_NAV_OPEN_KEYS,
        navOpenKeys: navOpenKeys
    }
}

export function handleSwitchMenuPopover(){
    return {
        type: APP_CHANGE_SWITCH_MENU_POPOVER
    }
}

export function handleSwitchSider(){
    return {
        type: APP_CHANGE_SWITCH_SIDER
    }
}

export function resetState(){
    return {
        type: APP_RESET_STATE
    }
}

export function loadingFlag(flag){
    return {
        type: APP_LOADING_FLAG,
        flag: flag
    }
}

export function changeUserPassword(params) {
    return () => {
        fetchData(REQUEST_WAR_NAME + '/operWorkbench/updateHisPasswdInfo.do', {body: JSON.stringify(params)}).then(
            response => {
                let flag = response.flag;
                if (typeof flag !== 'undefined' && flag === 1) {
                    notification.info({
                        placement: 'bottomLeft',
                        message: '修改密码',
                        description: '密码修改成功',
                        className: 'notification-success'
                    });
                } else {
                    notification.info({
                        placement: 'bottomLeft',
                        message: '修改密码',
                        description: '密码修改失败',
                        className: 'notification-failed'
                    });
                }
            }
        );
    }
}