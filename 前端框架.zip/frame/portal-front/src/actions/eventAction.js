/**
 * Created by lwj on 2017/7/4.
 */
import {EVENT_ACTION} from '../constants/CommonConstant'

export const EVENT_SOCKET_CONNECT_EVENT = 'EVENT_SOCKET_CONNECT_EVENT';
export const EVENT_SOCKET_CONNECT = 'EVENT_SOCKET_CONNECT';
export const EVENT_SOCKET_DISCONNECT = 'EVENT_SOCKET_DISCONNECT';


export function connectEventSocket(user){
    return {
        type: EVENT_SOCKET_CONNECT_EVENT,
        [EVENT_ACTION]: {
            type: EVENT_SOCKET_CONNECT,
            user: user
        }
    }
}

export function disconnectEventSocket() {
    return {
        type: EVENT_SOCKET_CONNECT_EVENT,
        [EVENT_ACTION]:{
            type: EVENT_SOCKET_DISCONNECT
        }
    }
}