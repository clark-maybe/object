/**
 * Created by lwj on 2017/4/27.
 */
import 'babel-polyfill'
import {REQUEST_WAR_NAME} from '../constants/CommonConstant'
import history from '../history'

export function locationChange(path){
    return {
        type : 'LOCATION_CHANGE',
        path: path
    }
}

export function login(){
    return (dispatch, getState) => {
        // dispatch(resetState());
        var str = [];
        var user = {username: 'test6@1', password: '123456'};
        for (var p in user) {
            str.push(encodeURIComponent(p) + '=' + encodeURIComponent(user[p]));
        }
        fetch(REQUEST_WAR_NAME + '/login', {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            body: str.join('&')
        }).then(response => {
            if (response.ok) {
                history.push('/hc');
            }
        }).catch(function (e) {
            // dispatch(loginFailure(e));
        });
    }
}