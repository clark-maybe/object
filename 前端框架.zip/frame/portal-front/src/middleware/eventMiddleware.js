/**
 * Created by lwj on 2017/7/4.
 */
import {EVENT_ACTION, REQUEST_WAR_NAME, JOB_CODE_REC, JOB_CODE_RECEPTION, JOB_CODE_DOCTOR
    , NOTIFICATION_TAG_PAY, NOTIFICATION_TAG_RESERVATION} from '../constants/CommonConstant'
import {EVENT_SOCKET_CONNECT, EVENT_SOCKET_DISCONNECT} from '../actions/eventAction'
import {refreshToDay} from '../actions/portalMainAction'
import {formatMoney} from '../utils/formatUtils'
// import {refreshReceptionFlag} from '../actions/work/receptionWorkTodayResvAction'
// import {refreshDoctorFlag} from '../actions/work/doctorWorkResvAction'
// import {refreshConsult} from '../actions/work/consultWorkResvAction'
import SockJS from 'sockjs-client'
import Stomp from 'stompjs'
import history from '../history'
import {notification} from 'antd'
import moment from 'moment'

var mspSocket;
var stompClient;

var reconnectTimeout = null;
var reconnectAttempts = 0;
var maxReconnectAttempt = 20;
var notifyTimeout = null;

export default store => next => action => {

    const eventAction = action[EVENT_ACTION];
    if(!eventAction){
        return next(action);
    }

    const {type} = eventAction;
    switch (type) {
        case EVENT_SOCKET_CONNECT:
            connectMsp(eventAction.user);
            return false;
        case EVENT_SOCKET_DISCONNECT:
            disconnectMsp();
            return false;
        default:
            return false;
    }

    function notify(title, text, iconUrl, relateUrl, tag){
        var options = {
            body: text,
            icon: iconUrl,
            renotify: true,
            tag: tag,
            requireInteraction: true
        };
        if (window.Notification && Notification.permission === 'granted') {
            var n = new Notification(title, options);
            if(!!notifyTimeout){
                clearTimeout(notifyTimeout);
                notifyTimeout = null;
            }
            if(relateUrl){
                n.onclick = function(event) {
                    // event.preventDefault(); // prevent the browser from focusing the Notification's tab
                    window.focus();
                    n.close();
                    history.push(relateUrl);
                };
                if(store.getState().hisMain.get('focused')) {
                    notifyTimeout = setTimeout(n.close.bind(n), 30000);
                }
            }else{
                if(store.getState().hisMain.get('focused')) {
                    notifyTimeout = setTimeout(n.close.bind(n), 30000);
                }
            }
        }

        // 如果用户没有选择是否显示通知
        // 注：因为在 Chrome 中我们无法确定 permission 属性是否有值，因此
        // 检查该属性的值是否是 'default' 是不安全的。
        else if (window.Notification && Notification.permission !== 'denied') {
            Notification.requestPermission(function (status) {
                if (Notification.permission !== status) {
                    Notification.permission = status;
                }

                // 如果用户同意了
                if (status === 'granted') {
                    var n = new Notification(title, options);
                    if(!!notifyTimeout){
                        clearTimeout(notifyTimeout);
                        notifyTimeout = null;
                    }
                    if(relateUrl){
                        n.onclick = function(event) {
                            // event.preventDefault(); // prevent the browser from focusing the Notification's tab
                            window.focus();
                            n.close();
                            history.push(relateUrl);
                        };
                        if(store.getState().hisMain.get('focused')) {
                            notifyTimeout = setTimeout(n.close.bind(n), 30000);
                        }
                    }else{
                        if(store.getState().hisMain.get('focused')) {
                            notifyTimeout = setTimeout(n.close.bind(n), 30000);
                        }
                    }
                }
                // 否则，我们可以让步的使用常规模态的 alert
                else {
                    notification['info']({
                        message: title,
                        description: text,
                        duration:5
                    });
                }
            });
        }
        // 如果用户拒绝接受通知
        else {
            // 我们可以让步的使用常规模态的 alert
            notification['info']({
                message: title,
                description: text,
                duration:5
            });
        }
    }

    function connectMsp(user) {
        mspSocket = new SockJS(REQUEST_WAR_NAME+'/ws');
        stompClient = Stomp.over(mspSocket);
        stompClient.heartbeat.outgoing = 20000;
        stompClient.heartbeat.incoming = 60000;
        stompClient.connect({}, function(frame) {
            // console.log('Connected: ' + frame);
            reconnectAttempts = 0;
            if(reconnectTimeout){
                clearTimeout(reconnectTimeout);
                reconnectTimeout = null;
            }
            const notifictionIcon = store.getState().hisMain.get('notifictionIcon');

        }, function(e){
            if(reconnectTimeout){
                clearTimeout(reconnectTimeout);
                reconnectTimeout = null;
            }
            if(reconnectAttempts < maxReconnectAttempt){
                reconnectAttempts++;
                reconnectTimeout = setTimeout(
                    function () {
                        connectMsp(user);
                    }
                    , 5000);
            }
        });
    }

    function disconnectMsp() {
        if (!!stompClient) {
            stompClient.disconnect(function () {
                console.info('See you next time!');
            });
            stompClient = null;
        }
        if(!!mspSocket){
            mspSocket = null;
        }
    }
}