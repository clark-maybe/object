/**
 * Created by lwj on 2017/4/28.
 */
import React from 'react'
import {Modal, Form, Button, Select} from 'antd'
import {connect} from 'react-redux'
import {is} from 'immutable'
import history from '../../history'
import {login, reset, clearSockets} from '../../actions/login/loginAction'
import {resetState} from '../../actions/portalMainAction'
import LoginForm from '../../components/login/LoginForm'
import logoImg from '../../styles/img/logo_mantis.png'
const createForm = Form.create;
const FormItem = Form.Item;
const Option = Select.Option;
import appStyle from '../../App.css';

class Login extends React.Component {

    constructor(props) {
        super(props);
        this.handleLogin = this.handleLogin.bind(this);
        this.handleSelectCancel = this.handleSelectCancel.bind(this);
        this.handleSelectSubmit = this.handleSelectSubmit.bind(this);
        this.state = {
            redirectToReferrer: false,
            isShowSelectClinicModal: false,
            errorTime: new Date().getTime(),
            submitting: false,
            resetTime: new Date().getTime()
        };
    }

    componentDidMount() {
        const {resetState, clearSockets} = this.props;
        resetState();
        clearSockets();
    }

    componentWillReceiveProps(nextProps) {
        if (!!nextProps.clinicList && nextProps.clinicList.size >  0) {
            if (nextProps.clinicList.size === 1) {
                history.push({
                    pathname: '/hc',
                    state: {clinicId: nextProps.clinicList.get(0).get('orgId')}
                });
            } else if (!is(this.props.clinicList, nextProps.clinicList) && nextProps.clinicList.size > 1) {
                this.setState({isShowSelectClinicModal: true});
            }
        } else {
            if(!!nextProps.clinicList){
                history.push({
                    pathname: '/hc',
                    state: {clinicId: null}
                });
            }
        }
    }

    handleLogin(data) {
        this.props.login(data);
    }

    handleSelectCancel() {
        this.setState({submitting: false, isShowSelectClinicModal: false});
        const {reset} = this.props;
        reset();
    }

    handleSelectSubmit() {
        let self = this;
        this.setState({submitting: true});
        if (this.handleSelectSubmit.t) {
            this.handleSelectSubmit.t = null;
        }
        this.handleSelectSubmit.t = setTimeout(() => {
            self.props.form.validateFields((errors) => {
                if (!!errors) {
                    self.setState({errorTime: new Date().getTime(), submitting: false});
                    return;
                }
                history.push({
                    pathname: '/hc',
                    state: {clinicId: self.props.form.getFieldValue('clinicId')}
                });
            });
        }, 500);
    }

    render() {
        const {getFieldDecorator} = this.props.form;
        const {errorMessage, clinicList, resetTime, reset} = this.props;
        return (
            <div style={{height:'100%', width:'100%', display: 'flex'}}>
                <div className={appStyle.AppBackGroundLeft}></div>
                <div className={appStyle.AppBackGroundRight}>
                    <div style={{width:400, marginTop: '30%'}}>
                        <div style={{padding:20}}>
                            <div style={{marginTop:20, marginBottom:50}}>
                                <img width='85%' alt="logo" src={logoImg}/>
                            </div>
                            <div><span style={{color: '#f04134'}}>{errorMessage}</span></div>
                            <LoginForm handleLogin={this.handleLogin} errorMessage={errorMessage} resetTime={resetTime} reset={reset}/>
                            <div style={{textAlign:'center',color: '#687178',marginTop: 100, transform: 'scale(0.8)'}}>
                                <p style={{fontStyle: 'italic'}}>Originate From Dental Not Only Dental</p>
                                <p>一切与牙无关 一切与人有关</p>
                                <p>Mantis © 2017</p>
                            </div>
                        </div>

                        <Modal title="请选择门诊" visible={this.state.isShowSelectClinicModal}
                               maskClosable={false} onCancel={this.handleSelectCancel} closable={true}
                               footer={[
                                <Button key="back" size="large" onClick={this.handleSelectCancel}>取消</Button>,
                                <Button key="submit" type="primary" size="large"
                                        loading={this.state.submitting} onClick={this.handleSelectSubmit}>
                                    确定
                                </Button>
                            ]}>
                            <Form layout="horizontal">
                                <FormItem wrapperCol={{ span: 24 }}>
                                    {getFieldDecorator('clinicId',
                                        {rules: [{required: true, message: '门诊为空'}]}
                                    )(<Select placeholder="请选择门诊">
                                        {!!clinicList ?
                                            clinicList.map(opt => {
                                                return (
                                                    <Option key={opt.get('orgId')+''}
                                                            value={opt.get('orgId')+''}>{opt.get('orgName')}</Option>);
                                            }): null
                                        }
                                    </Select>)}
                                </FormItem>
                            </Form>
                        </Modal>
                    </div>
                </div>
            </div>
        );
    }
}

function mapStateToAppProps(state) {
    return {
        clinicList: state.login.get('clinicList'),
        resetTime: state.login.get('resetTime'),
        errorMessage: state.login.get('errorMessage')
    };
}

Login = createForm({})(Login);
export default connect(mapStateToAppProps, {login, resetState, reset, clearSockets})(Login);

