import React from 'react';
import {connect} from 'react-redux';
import classnames from 'classnames';
import {createSelector} from 'reselect';
import {
    DOCUMENT_TYPE_CODE, HC_MANTIS_SEX_CODE
} from '../constants/CommonConstant';
import {Switch, Route} from 'react-router-dom';
import Header from '../components/layout/Header';
import Sider from '../components/layout/Sider';
import styles from '../components/layout/main.less';
import {Spin} from 'antd';
import '../components/layout/common.less';
import {logout} from '../actions/login/loginAction';
import {changeMainPath} from '../actions/commonAction';
import {
    loadUserData, changeNavOpenKeys, handleSwitchMenuPopover, handleSwitchSider, changeUserPassword
} from '../actions/portalMainAction';
// import {addStudent} from '../actions/student/studentDetailBaseAction';
import {fromJS} from 'immutable'

const NoMatch = ({location}) => (
    <div>
        <h3>No match for <code>{location.pathname}</code></h3>
    </div>
);
class PortalMain extends React.Component {

    constructor(props) {
        super(props);
        this.renderSider = this.renderSider.bind(this);
        this.renderHeader = this.renderHeader.bind(this);
        this.switchMenuPopover = this.switchMenuPopover.bind(this);
        this.handleLogout = this.handleLogout.bind(this);
        this.switchSider = this.switchSider.bind(this);
        this.changeOpenKeys = this.changeOpenKeys.bind(this);
        this.changeTheme = this.changeTheme.bind(this);
    }

    componentWillMount() {
        const {
            loadUserData, currPath
        } = this.props;
        let schoolId = !!this.props.location.state ? this.props.location.state.schoolId : null;
        loadUserData(currPath, {schoolId: !!schoolId ? schoolId : null});
        window.addEventListener('beforeunload', this.leaveCallback);
        if (window.Notification && Notification.permission !== 'denied') {
            Notification.requestPermission(function (status) {
                if (Notification.permission !== status) {
                    Notification.permission = status;
                }
            })
        }
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.currPath !== nextProps.currPath) {
            nextProps.changeMainPath(nextProps.currPath);
        }
    }

    leaveCallback(e) {
        var confirmationMessage = 'HC系统不会自动保存数据，请确认数据都已妥善保存！';
        (e || window.event).returnValue = confirmationMessage; //Gecko + IE
        return confirmationMessage;
    }

    componentWillUnmount() {
        window.removeEventListener('beforeunload', this.leaveCallback);
    }

    renderSider() {
        const {isNavBar, darkTheme, siderFold, navOpenKeys, functions, currPath} = this.props;
        if (!isNavBar) {
            return (
                <aside className={classnames(styles.sider, {[styles.light]: !darkTheme})}>
                    <Sider
                        siderFold={siderFold} isNavBar={isNavBar} functions={functions}
                        navOpenKeys={navOpenKeys} changeOpenKeys={this.changeOpenKeys}
                        changeTheme={this.changeTheme} darkTheme={darkTheme} currPath={currPath}
                    />
                </aside>
            )
        }
    }

    switchMenuPopover() {
        const {handleSwitchMenuPopover} = this.props;
        handleSwitchMenuPopover()
    }

    handleLogout() {
        const {logout} = this.props;
        logout();
    }

    switchSider() {
        const {handleSwitchSider} = this.props;
        handleSwitchSider()
    }

    changeOpenKeys(openKeys) {
        const {changeNavOpenKeys} = this.props;
        changeNavOpenKeys(openKeys);
    }

    changeTheme() {

    }

    renderHeader() {
        const {
            user, menuPopoverVisible, siderFold, isNavBar, navOpenKeys, addStudent, areaList, sexCodes
            , functions, currPath, typeCodes, documentTypeCodes, mscCodes, changeUserPassword, logout
        } = this.props;
        return (
            <Header
                user={user} siderFold={siderFold} isNavBar={isNavBar} functions={functions} addStudent={addStudent}
                menuPopoverVisible={menuPopoverVisible} navOpenKeys={navOpenKeys} currPath={currPath}
                changeUserPassword={changeUserPassword} mainPath={this.props.location.pathname} logout={logout}
                mscCodes={mscCodes} sexCodes={sexCodes} areaList={areaList} documentTypeCodes={documentTypeCodes}
                switchSider={this.switchSider} changeOpenKeys={this.changeOpenKeys} typeCodes={typeCodes}
            />
        )
    }

    render() {
        const {isNavBar, siderFold, loading} = this.props;
        return (
            <div>
                <div
                    className={classnames(styles.layout, {[styles.fold]: isNavBar ? false : siderFold}, {[styles.withnavbar]: isNavBar})}>
                    {this.renderSider()}
                    <div className={styles.main}>
                        <Spin spinning={loading}>
                            {this.renderHeader()}
                            <div className={styles.container}>
                                <div className={styles.content}>
                                    <Switch>
                                        <Route component={NoMatch}/>
                                    </Switch>
                                </div>
                            </div>
                        </Spin>
                    </div>
                </div>
            </div>
        )
    }
}

const getFunctions = (state, ownProps) => state.portalMain.get('functions');

const getUser = (state, ownProps) => state.portalMain.get('user');

const getMainPath = (state, ownProps) => ownProps.location.pathname;
const getCurrFuncPath = createSelector(
    [getMainPath, getFunctions], (mainPath, functions) => {
        let findFunc = functions.find(value => {
            if (!!mainPath && mainPath.indexOf(value.get('funcAction')) !== -1) {
                return true;
            }
            return false;
        });
        if (!!findFunc && !!findFunc.get('children') && !!findFunc.get('children').size > 0 && !!findFunc.getIn(['children', 0, 'funcAction'])) {
            findFunc = findFunc.get('children').find(value => {
                if (!!mainPath && mainPath.indexOf(value.get('funcAction')) !== -1) {
                    return true;
                }
                return false;
            });
        }
        if (!!findFunc && !!findFunc.get('children') && !!findFunc.get('children').size > 0 && !!findFunc.getIn(['children', 0, 'funcAction'])) {
            findFunc = findFunc.get('children').find(value => {
                if (!!mainPath && mainPath.indexOf(value.get('funcAction')) !== -1) {
                    return true;
                }
                return false;
            });
        }
        return !!findFunc ? findFunc.get('funcAction') : mainPath;
    }
);

const mapStateToAppProps = (state, ownProps) => {
    const thisState = state.portalMain;
    return {
        isNavBar: thisState.get('isNavBar'),
        darkTheme: thisState.get('darkTheme'),
        functions: getFunctions(state, ownProps),
        user: getUser(state, ownProps),
        defaultSchoolId: thisState.get('defaultSchoolId'),
        navOpenKeys: thisState.get('navOpenKeys'),
        menuPopoverVisible: thisState.get('menuPopoverVisible'),
        siderFold: thisState.get('siderFold'),
        loading: thisState.get('loading'),
        currPath: getCurrFuncPath(state, ownProps),
        areaList: thisState.get('areaList'),
        documentTypeCodes: !!thisState.getIn(['dictMap', DOCUMENT_TYPE_CODE]) ? thisState.getIn(['dictMap', DOCUMENT_TYPE_CODE]) : fromJS([]),
        sexCodes: !!thisState.getIn(['dictMap', HC_MANTIS_SEX_CODE]) ? thisState.getIn(['dictMap', HC_MANTIS_SEX_CODE]) : fromJS([])
    }
};

export default connect(mapStateToAppProps, {
    logout,
    changeMainPath,
    loadUserData,
    changeNavOpenKeys,
    handleSwitchMenuPopover,
    handleSwitchSider,
    changeUserPassword,
    // addStudent
    // add,
    // addRegister,
    // edit
})(PortalMain)