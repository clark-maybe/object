/**
 * Created by lwj on 2017/6/28.
 */
import React from 'react'
import {Alert} from 'antd'

export default class NoAuthenticate extends React.Component{
    
    render(){
        return (<div>
            <Alert
                message="系统提示"
                description="当前登录用户没有该功能的权限！"
                type="info"
                showIcon
            />
        </div>)
    }
}