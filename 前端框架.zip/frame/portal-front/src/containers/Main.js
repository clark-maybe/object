/**
 * Created by lwj on 2017/4/27.
 */
import 'babel-polyfill'
import React from 'react'
import { connect } from 'react-redux'
import ReactDOM from 'react-dom'
import {Link, Route} from 'react-router-dom'
import {locationChange, login} from '../actions/locationAction'
import External from '../components/reservation/External';
import {Button, Modal, Popover} from 'antd'
var $ = require('jquery');
var moment = require('moment');
require('../../node_modules/fullcalendar/dist/fullcalendar');
import '../../node_modules/fullcalendar/dist/fullcalendar.css'
require('../../node_modules/fullcalendar/dist/locale/zh-cn');

class Main extends React.Component {

    constructor(props){
        super(props);
        this.handleLogin = this.handleLogin.bind(this);
        this.handleClick = this.handleClick.bind(this);
    }

    componentDidMount() {
        var doctors = {'9:00': 'b', '9:15': 'c'};
        $('#calendar').fullCalendar({
            defaultView: 'agenda',
            visibleRange: {
                start: '2017-03-22',
                end: '2017-03-25'
            },
            height: 800,
            timezone: "local",

            selectable:true,
            selectOverlap:false,
            selectConstraint:{
                start: '09:00', // a start time (10am in this example)
                end: '18:00', // an end time (6pm in this example)
            },
            firstDay:0,
            allDaySlot: false,
            minTime: '09:00:00',		//设置显示的时间从几点开始，作用于agendaWeek和agendaDay
            maxTime: '12:00:00',		//设置显示的时间从几点结束，作用于agendaWeek和agendaDay
            slotLabelFormat: 'H:mm',			//设置日历agenda视图下左侧的时间显示格式，默认h(:mm)a
            slotDuration: '00:15:00',
            slotLabelInterval: '00:15:00',	//设置在agenda的视图中, 两个时间之间的间隔(分钟)
            editable : true,
            droppable: true,
            // this allows things to be dropped onto the calendar
            drop: function() {
                // is the "removeDispose after drop" checkbox checked?
                if ($('#drop-removeDispose').is(':checked')) {
                    // if so, removeDispose the element from the "Draggable Events" list
                    $(this).remove();
                }
            },
            eventReceive: function(event) {
                console.log(event);
                alert(event.title + " was dropped on " + event.start.format());
            },
            eventClick: function(calEvent, jsEvent, view) {

                alert('Event: ' + calEvent.title);
                alert('Coordinates: ' + jsEvent.pageX + ',' + jsEvent.pageY);
                alert('View: ' + view.name);

                // change the border color just for fun
                $(this).css('border-color', 'red');

            },
            dayClick: function(date, allDay, jsEvent, view) {

                if (allDay) {
                    alert('Clicked on the entire day: ' + date);
                }else{
                    alert('Clicked on the slot: ' + date);
                }

                alert('Coordinates: ' + jsEvent.pageX + ',' + jsEvent.pageY);

                // change the day's background color just for fun
                $(this).css('background-color', 'red');

            }
        });

    }

    handleLogin(){
        const {login} = this.props;
        login(this.props.history);
    }

    handleClick(id){
        Modal.info({
            title: "获取数据失败",
            content: "出错信息",
            onOk() {
                window.scheduler.deleteEvent(id);
            }
        })
    }

    render(){
        return (
            <div style={{height:'100%', width:'100%'}}>
                <div id="calendar" style={{width: '80%'}}></div>
                <div style={{position:'absolute', top:0, right: 0, width: '20%', height: '100%'}}>
                    <External/>
                </div>
            </div>
        )
    }
}

const mapStateToAppProps = (state, ownProps) => ({

});

export default connect(mapStateToAppProps, {locationChange, login})(Main)