/**
 * Created by lwj on 2017/4/27.
 */
import React from 'react'
import {Provider} from 'react-redux'
import App from './App'
import DevTools from './containers/DevTools';

const isProduction = process.env.NODE_ENV === 'production' 
    || process.env.NODE_ENV === 'production_dev' || process.env.NODE_ENV === 'production_mw';

export default class Root extends React.Component {
    render() {
        const {store} = this.props;
        return (
            <Provider store={store} style={{height:'100%', width:'100%'}}>
                <div id='hisroot' style={{height:'100%', width:'100%'}}>
                    <App/>
                    {!isProduction && <DevTools />}
                </div>
            </Provider>
        )
    }
}
