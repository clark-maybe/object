/**
 * Created by lwj on 2017/6/28.
 */

var buttonMap = {};


export function setButtonMap(value){
    buttonMap = value;
}


export function hasAuthorization(key){
    return !!buttonMap[key];
}