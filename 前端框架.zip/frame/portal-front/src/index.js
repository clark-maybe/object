import React from 'react';
import ReactDOM from 'react-dom';
import { createStore, applyMiddleware, compose } from 'redux'
import thunk from 'redux-thunk'
import eventMiddleware from './middleware/eventMiddleware'
import reducers from './reducers';
import Root from './Root';
import DevTools from './containers/DevTools';
import '../node_modules/fullcalendar/dist/fullcalendar.css'
import './index.css';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';

const isProduction = 
    process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'production_dev' || process.env.NODE_ENV === 'production_mw';

let store;
if (isProduction) {
    store = createStore(reducers, {}, applyMiddleware(thunk));
} else {
    /**
     * Only use the DevTools component
     * when in development.
     */
    store = createStore(reducers, {}, compose(applyMiddleware(thunk), DevTools.instrument()));
}

ReactDOM.render(
    <Root store={store}/>,
    document.getElementById('root')
);
