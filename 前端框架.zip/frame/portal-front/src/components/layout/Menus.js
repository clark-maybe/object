/**
 * Created by lwj on 2017/5/15.
 */
import React from 'react';
import {Menu} from 'antd'
import {NavLink} from 'react-router-dom'

const levelMap = {};
const getMenus = function (menuArray, siderFold, topMenus, parentFunc) {
    return menuArray.map(item => {
        if (!!item.children && item.children.length > 0 && !!item.children[0].funcAction) {
            if (item.parentId != 1) {
                levelMap["'" + item.funcAction + "'"] = parentFunc.funcAction;
            }
            return (
                <Menu.SubMenu key={item.funcAction} title={<span>{item.icon ?
                <i className={`menu-icon iconfont icon-${item.icon}`}/> : <i className="menu-icon iconfont icon-mulu"/>}{siderFold && topMenus.indexOf(item.funcAction) >= 0 ? '' : item.funcDesc}</span>}
                              className="Menus">
                    {getMenus(item.children, siderFold, topMenus, item)}
                </Menu.SubMenu>
            )
        } else {
            return (
                <Menu.Item key={item.funcAction}>
                    <NavLink to={item.funcAction} title={siderFold && topMenus.indexOf(item.funcAction) >= 0 ? '' : item.funcDesc}>
                        {item.icon ? <i className={`menu-icon iconfont icon-${item.icon}`}/> :
                            <i className="menu-icon iconfont icon-mulu"/>}
                        {siderFold && topMenus.indexOf(item.funcAction) >= 0 ? '' : item.funcDesc}
                    </NavLink>
                </Menu.Item>
            )
        }
    })
};

const getAncestorKeys = (key) => {
    return [levelMap["'" + key + "'"]] || [];
};

export default class Menus extends React.Component {

    constructor(props) {
        super(props);
        this.onOpenChange = this.onOpenChange.bind(this);
    }

    onOpenChange(openKeys) {
        const {changeOpenKeys, navOpenKeys} = this.props;
        const latestOpenKey = openKeys.find(key => !(navOpenKeys.toJS().indexOf(key) > -1));
        const latestCloseKey = navOpenKeys.toJS().find(key => !(openKeys.indexOf(key) > -1));
        let nextOpenKeys = [];
        if (latestOpenKey) {
            nextOpenKeys = getAncestorKeys(latestOpenKey).concat(latestOpenKey)
        }
        if (latestCloseKey) {
            nextOpenKeys = getAncestorKeys(latestCloseKey)
        }
        changeOpenKeys(nextOpenKeys)
    }

    render() {
        const {siderFold, navOpenKeys, darkTheme, handleClickNavMenu, functions, currPath} = this.props;
        const topMenus = functions.toJS().map(item => item.funcAction);
        const menuItems = getMenus(functions.toJS(), siderFold, topMenus, null);
        let menuProps = !siderFold ? {
            onOpenChange: this.onOpenChange,
            openKeys: navOpenKeys.toJS()
        } : {};
        return (
            <div>
                <Menu
                    {...menuProps}
                    mode={siderFold ? 'vertical' : 'inline'}
                    theme={darkTheme ? 'dark' : 'light'}
                    onClick={handleClickNavMenu}
                    selectedKeys={[currPath]}
                >
                    {menuItems}
                </Menu>
                <div style={{textAlign:'center', position: 'absolute', left: 0, bottom: 0, fontSize: 12, transform: 'scale(0.6)',
    color: 'rgba(153, 153, 153, 0.54)', display: siderFold ? 'none' : 'block'}}>
                    <p>一切与牙无关 一切与人有关</p>
                    <p style={{fontStyle: 'italic'}}>Originate From Dental Not Only Dental</p>
                </div>
            </div>
        )
    }

}