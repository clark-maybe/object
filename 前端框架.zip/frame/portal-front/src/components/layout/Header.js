/**
 * Created by lwj on 2017/5/15.
 */
import React from 'react'
import { Menu, Icon, Button, notification, Modal, Popover, Popconfirm } from 'antd'
import styles from './header.less'
import {fromJS} from 'immutable'
import {REQUEST_WAR_NAME, CUSTOMER_ADD_AND_ORDER} from '../../constants/CommonConstant';
import {fetchData} from '../../utils/fetchService'
// import CustomerSearch from '../student/CustomerSearch'
import moment from 'moment'
// import StudentAddModal from '../student/StudentAddModal'
import ChangeUserPasswordForm from '../common/ChangeUserPasswordForm'
// import {addStudent} from '../../actions/student/studentAction'
import history from '../../history'

const SubMenu = Menu.SubMenu;

export default class Header extends React.Component {

    constructor(props){
        super(props);
        this.handleMenuClick = this.handleMenuClick.bind(this);
        this.handleAddCustomerCancel = this.handleAddCustomerCancel.bind(this);
        this.handleAddCustomerSubmit = this.handleAddCustomerSubmit.bind(this);
        this.handleShowAddStudent = this.handleShowAddStudent.bind(this);
        this.handleShowAddOrder = this.handleShowAddOrder.bind(this);
        this.handleVisibleChange = this.handleVisibleChange.bind(this);
        this.changePassword = this.changePassword.bind(this);
        this.changePasswordSubmit = this.changePasswordSubmit.bind(this);
        this.changePasswordCancel = this.changePasswordCancel.bind(this);
        this.state = {
            showAddCustomerModal: false,
            showAddRegisterModal: false,
            isShowChangePasswordModal: false,
            customer: fromJS({}),
            visible: false
        }
    }

    /**
     * 修改密码
     * @param record
     */
    changePassword() {
        this.setState({isShowChangePasswordModal: true});
    }

    /**
     * 修改密码提交
     */
    changePasswordSubmit(values) {
        const {changeUserPassword, user} = this.props;
        let params = {};
        params.userId = user.get('id');
        params.password = values.password;
        changeUserPassword(params);
        this.setState({isShowChangePasswordModal: false});
    }

    /**
     * 修改密码取消
     */
    changePasswordCancel() {
        this.setState({isShowChangePasswordModal: false});
    }

    handleVisibleChange(visible) {
        this.setState({visible});
    }

    componentWillReceiveProps(nextProps){
        // if((this.props.registerCustomer.get('id') !== nextProps.registerCustomer.get('id')
        //     && !!nextProps.registerCustomer.get('id')) || this.props.addRegisterTime !== nextProps.addRegisterTime){
        //     this.setState({showAddRegisterModal: true, student: fromJS(nextProps.registerCustomer)});
        // }
    }

    handleMenuClick(e){
        const {logout} = this.props;
        if(e.key === 'logout'){
            logout();
        }else if(e.key === 'modifyPassword'){
            this.changePassword();
        }
    }

    handleShowAddStudent() {
        this.setState({showAddCustomerModal: true});
    }

    handleAddCustomerCancel() {
        this.setState({showAddCustomerModal: false});
    }

    handleAddCustomerSubmit(params, type){
        this.setState({showAddCustomerModal: false});
        const {addStudent, mainPath} =this.props;
        if(type === CUSTOMER_ADD_AND_ORDER){
            addStudent(params, mainPath);
        }else{
            addStudent(params, null);
        }
    }

    handleShowAddOrder(customer) {
        const {mainPath} = this.props;
        history.push({pathname: `/hc/student/detail/${customer.id}/enroll/add`,
            state: {
                backUrl:  mainPath
            }});
    }

    render() {
        const {siderFold, switchSider, user, documentTypeCodes, sexCodes, areaList} = this.props;
        const trigger = 'click';
        return (
            <div className={styles.header}>
                <div style={{display: 'flex', alignItems: 'center'}}>
                    <div className={styles.button} onClick={switchSider}>
                        <Icon type={siderFold ? 'menu-unfold' : 'menu-fold'} />
                    </div>
                    <div>
                        <h3>{user.get('loginOrgName')}</h3>
                    </div>
                </div>

                <div style={{display: 'flex', alignItems: 'center'}}>
                    {/*<Button type="primary" icon="plus-circle" onClick={this.handleShowAddStudent}>新增学员</Button>*/}
                    {/*<CustomerSearch showAddStudent={true} showOrder={true} changeRoute={true}*/}
                                    {/*style={{ width: 200, marginLeft: 10 }} tip="查询电话"*/}
                                    {/*trigger={trigger} showNotFound={true} requestAction="/hcCustomer/queryList.do"*/}
                                    {/*handleShowAddOrder={this.handleShowAddOrder}*/}
                                    {/*handleShowAddStudent={this.handleShowAddStudent}/>*/}
                    <Menu className='header-menu' mode='horizontal' onClick={this.handleMenuClick}>
                        <SubMenu title={<span> <Icon type='user' />
                            {user.get('name')} </span>}>
                            <Menu.Item key='logout'><Icon type="logout" />注销</Menu.Item>
                            <Menu.Item key='modifyPassword'><Icon type="edit" />修改密码</Menu.Item>
                        </SubMenu>
                    </Menu>
                </div>
                <ChangeUserPasswordForm user={user}
                                        isShowChangePasswordModal={this.state.isShowChangePasswordModal}
                                        changePasswordSubmit={this.changePasswordSubmit}
                                        changePasswordCancel={this.changePasswordCancel}/>
                {/*<StudentAddModal documentTypeCodes={documentTypeCodes}*/}
                                 {/*sexCodes={sexCodes} showModal={this.state.showAddCustomerModal}*/}
                                 {/*areaList={areaList}*/}
                                 {/*handleSubmit={this.handleAddCustomerSubmit} handleCancel={this.handleAddCustomerCancel}/>*/}
            </div>
        )
    }

}