/**
 * Created by lwj on 2017/4/28.
 */
import React from 'react'
import styles from './main.less'
import Menus from './Menus'
import logoImg from '../../styles/img/meiwei/logo.png'
import xiaomeiImg from '../../styles/img/meiwei/xiaomei.png'

export default class Slider extends React.Component {
    
    render(){
        const {siderFold, darkTheme, functions, currPath, navOpenKeys, changeOpenKeys} = this.props;
        return (
            <div>
                <div className={styles.logo}>
                    {!siderFold ? 
                        <img className={styles.largeLogo} src={logoImg} alt="DR.XIAOMEI"/> :
                        <img className={styles.smallLogo} src={xiaomeiImg} alt="DR.XIAOMEI"/>
                    }
                </div>
                <Menus siderFold={siderFold} darkTheme={darkTheme} functions={functions}
                       navOpenKeys={navOpenKeys} changeOpenKeys={changeOpenKeys} currPath={currPath}
                />
                {
                    /**
                    !siderFold ? <div className={styles.switchtheme}>
                    <span><Icon type='bulb' />切换主题</span>
                    <Switch onChange={changeTheme} defaultChecked={darkTheme} checkedChildren='黑' unCheckedChildren='白' />
                </div> : ''
                     */
                }
            </div>
        )
    }
    
}