/**
 * Created by lwj on 2016/5/24.
 */
import React from 'react'
import {Form, Input, Button} from 'antd';
const createForm = Form.create;
const FormItem = Form.Item;

const nodeEnv = process.env.NODE_ENV;
// === 'production'
// || process.env.NODE_ENV === 'production_dev' || process.env.NODE_ENV === 'production_mw';


class LoginForm extends React.Component {

    constructor(props) {
        super(props);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.state = {
            submitting: false
        }
    }

    handleSubmit() {
        const {handleLogin, form, reset} = this.props;
        if(this.state.submitting){
            return;
        }
        this.setState({submitting: true});
        form.validateFields((errors, values) => {
            if (!!errors) {
                reset();
                return;
            }
            if(nodeEnv === 'production_dev' || nodeEnv === 'development'){
                values.username += '@6114';
            }else{
                values.username += '@6114';
            }
            handleLogin(values);
        });
    }

    componentWillReceiveProps(nextProps) {
        if((this.props.errorMessage !== nextProps.errorMessage && !!nextProps.errorMessage)
            || this.props.resetTime !== nextProps.resetTime){
            this.setState({submitting: false});
        }
    }

    render() {
        const {getFieldDecorator} = this.props.form;
        return (
            <Form layout='horizontal'>
                <FormItem hasFeedback wrapperCol={{ span: 24 }}>
                    {getFieldDecorator('username', {
                        rules: [
                            {required: true, whitespace: true, message: '用户名为空'}
                        ]
                    })(
                        <Input placeholder=" 请输入用户名"/>
                    )}
                </FormItem>
                <FormItem hasFeedback wrapperCol={{ span: 24 }}>
                    {getFieldDecorator('password', {
                        rules: [
                            {required: true, whitespace: true, message: '密码为空'}
                        ]
                    })(
                        <Input placeholder=" 请输入密码" autoComplete="off"
                               type="password"/>
                    )}
                </FormItem>
                <FormItem wrapperCol={{ span: 24}}>
                    <Button type="primary" htmlType="submit" style={{width:'100%'}}
                            loading={this.state.submitting} onClick={this.handleSubmit}>登录</Button>
                </FormItem>
            </Form>
        )
    }
}

LoginForm = createForm()(LoginForm);
export default LoginForm;

