/**
 * Created by zsp on 2018/5/17.
 */
import React from 'react';
import {TimePicker} from 'antd'
import moment from 'moment';
export default class TimePickerState extends React.Component {
    constructor() {
        super();
        this.state = {
            stardTimeValue: '',
            endTimeValue: '',
            errorFlag: false
        }
    }

    componentWillReceiveProps(nextProps) {
        let {record} = nextProps;
        this.setState({
            errorFlag: record.errorTime
        })
    }

    handleChangeStartTime = value => {
        let {record, saveChange, dataList} = this.props;
        let startTime = value ? value.clone().format('HH:mm') : '';
        dataList = dataList.map(item => {
            if (item.key === record.key) {
                let hour = Number((moment(item.endTime, 'HH:mm').diff(value, 'minutes') / 60).toFixed(1));
                item.startTime = startTime;
                item.actualDetailHour = !hour || hour < 0 ? 0 : hour;
            }
            return item;
        });
        saveChange(dataList, record);
    };
    handleChangeEndTime = value => {
        let {record, saveChange, dataList} = this.props;
        let endTime = value ? value.clone().format('HH:mm') : '';
        dataList = dataList.map(item => {
            if (item.key === record.key) {
                let hour = Number((value.diff(moment(item.startTime, 'HH:mm'), 'minutes') / 60).toFixed(1));
                item.endTime = endTime;
                item.actualDetailHour = !hour || hour < 0 ? 0 : hour;
            }
            return item;
        });
        saveChange(dataList, record);
    };

    render() {
        let {record} = this.props;
        return (
            <span>
                <TimePicker format="HH:mm"
                            style={{
                                marginRight: 10,
                                width: 120,
                                border: this.state.errorFlag ? '1px solid red' : '1px solid #d9d9d9'
                            }}
                            defaultValue={record.startTime ? moment(record.startTime, 'HH:mm') : null}
                            onChange={this.handleChangeStartTime}/>
                <TimePicker format="HH:mm"
                            style={{
                                marginRight: 10,
                                width: 120,
                                border: this.state.errorFlag ? '1px solid red' : '1px solid #d9d9d9'
                            }}
                            defaultValue={record.endTime ? moment(record.endTime, 'HH:mm') : null}
                            onChange={this.handleChangeEndTime}/>
            </span>
        )
    }
}