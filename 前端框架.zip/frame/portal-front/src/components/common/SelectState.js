/**
 * Created by zsp on 2018/4/26.
 */
import React from 'react';
import {Select} from 'antd';
const Option = Select.Option;
export default class SelectState extends React.Component {
    constructor() {
        super();
    }

    handleChange = value => {
        let {record, saveChange, dataIndex} = this.props;
        saveChange(record, value, dataIndex);
    };

    render() {
        let {lists, value} = this.props;
        return (
            <div>
                <Select style={{width: 200}} placeholder="请选择"
                        allowClear={true}
                        onChange={this.handleChange}
                        value={value ? value + '' : ''}
                >
                    {
                        lists.map(opt => {
                            return (<Option key={opt.id + ''}
                                            value={opt.id + ''}>
                                {opt.name}</Option>);
                        })
                    }
                </Select>
            </div>
        )
    }
}