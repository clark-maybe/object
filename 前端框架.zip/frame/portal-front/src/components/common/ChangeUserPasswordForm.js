/**
 * Created by hanzhengqiang on 16/9/6.
 */
import React, {Component} from 'react';
import {Modal, Form, Select, Input, Button} from 'antd';
import {is} from 'immutable'
import {fetchData} from '../../utils/fetchService'
import {REQUEST_WAR_NAME} from '../../constants/CommonConstant';
const createForm = Form.create;
const FormItem = Form.Item;
const Option = Select.Option;
/**
 * 修改用户密码
 */
class ChangeUserPasswordForm extends Component {

    constructor(props) {
        super(props);
        this.handleChangeUserPasswordValidate = this.handleChangeUserPasswordValidate.bind(this);
        this.passwordExists = this.passwordExists.bind(this);
        this.checkPassword = this.checkPassword.bind(this);
        this.checkRePassword = this.checkRePassword.bind(this);
        this.state = {
            errorTime: new Date().getTime(),
            submitting: false
        }
    }

    componentWillReceiveProps(nextProps) {
        if ((nextProps.isShowChangePasswordModal !== this.props.isShowChangePasswordModal
            && nextProps.isShowChangePasswordModal)
            || (nextProps.user.id !== this.props.user.id)) {
            this.setState({submitting: false});
            this.initFormValue(nextProps);
        }
    }

    initFormValue(props) {
        const {user} = props;
        let values = {
            name: user.get('name'),
            global_user_id: user.get('userId'),
            oldPasword: null,
            password: null,
            rePassword: null
        };
        props.form.setFieldsValue(values);
    }

    /**
     * 校验原密码
     * @param rule
     * @param value
     * @param callback
     */
    passwordExists(rule, value, callback) {
        const {user} = this.props;
        if (!value) {
            callback();
        } else {
            if (this.passwordExists.t) {
                clearTimeout(this.passwordExists.t);
                this.passwordExists.t = null;
            }
            this.passwordExists.t = setTimeout(() => {
                fetchData(REQUEST_WAR_NAME + '/operWorkbench/verificationPassword.do',
                    {body: JSON.stringify({userId: user.get('id'), password: value})}).then(
                    response => {
                        // if (typeof response === 'undefined' || response === null) {
                        //     response = {flag: 0, message: '内部错误，联系系统管理员'};
                        // }
                        let flag = response.flag;
                        if (typeof flag !== 'undefined' && flag === 1 && response.data) {
                            callback();
                        } else {
                            callback([new Error('原密码输入错误')]);
                        }
                    }
                );
            }, 800);
        }
    }

    /**
     * 校验密码
     * @param rule
     * @param value
     * @param callback
     */
    checkPassword(rule, value, callback) {
        if (!value) {
            callback();
        } else {
            if (this.checkPassword.t) {
                clearTimeout(this.checkPassword.t);
                this.checkPassword.t = null;
            }
            this.checkPassword.t = setTimeout(() => {
                if (value.length < 8 || value.length >16) {
                    callback([new Error('请输入8-16位密码')]);
                }
                let reg1 = new RegExp(/^[0-9A-Za-z]+$/);
                if (!reg1.test(value)) {
                    callback([new Error('请输入包含字母、数字的密码')]);
                }
                let reg = new RegExp(/[A-Za-z].*[0-9]|[0-9].*[A-Za-z]/);
                if (reg.test(value)) {
                    callback();
                } else {
                    callback([new Error('请输入包含字母、数字的密码')]);
                }
            }, 800);
        }
    }

    checkRePassword(rule, value, callback) {
        let password = this.props.form.getFieldValue('password');
        if (!value || !password) {
            callback();
        } else {
            if (this.checkRePassword.t) {
                clearTimeout(this.checkRePassword.t);
                this.checkRePassword.t = null;
            }
            this.checkRePassword.t = setTimeout(() => {
                if (value.length < 8 || value.length >16) {
                    callback([new Error('请输入8-16位确认密码')]);
                }
                if (password !== value) {
                    callback([new Error('确认密码输入错误')]);
                } else {
                    callback();
                }
            }, 800);
        }
    }

    /**
     * 验证
     */
    handleChangeUserPasswordValidate() {
        const {changePasswordSubmit} = this.props;
        this.setState({submitting: true});
        var self = this;
        if (this.handleChangeUserPasswordValidate.t) {
            this.handleChangeUserPasswordValidate.t = null;
        }
        this.handleChangeUserPasswordValidate.t = setTimeout(() => {
            self.props.form.validateFields({force: true}, (errors, values) => {
                if (!!errors) {
                    self.setState({errorTime: new Date().getTime(), submitting: false});
                    return;
                }
                changePasswordSubmit(values);
            });
        }, 500);
    }

    render() {
        const {getFieldDecorator} = this.props.form;
        const {isShowChangePasswordModal, changePasswordCancel, user} = this.props;
        let tempFooter = [
            <Button key="back" size="large" onClick={changePasswordCancel}>取消</Button>,
            <Button key="submit" type="primary" size="large"
                    loading={this.state.submitting} onClick={this.handleChangeUserPasswordValidate}>
                确定
            </Button>
        ];
        let title = '修改密码';
        if (user.get('flagPassword')) {
            tempFooter = [
                <Button key="submit" type="primary" size="large"
                        loading={this.state.submitting} onClick={this.handleChangeUserPasswordValidate}>
                    确定
                </Button>
            ];
            title = '请修改初始密码';
        }
        return (
            <Modal title={title} visible={isShowChangePasswordModal}
                   maskClosable={false} onCancel={changePasswordCancel}
                   footer={tempFooter}>
                <Form mode="horizontal">
                    <FormItem label="用户名" labelCol={{span: 8}} wrapperCol={{span: 16}}>
                        {getFieldDecorator('global_user_id')(
                            <Input disabled={true} style={{width: 200}}/>
                        )}
                    </FormItem>
                    <FormItem label="姓名" labelCol={{span: 8}} wrapperCol={{span: 16}}>
                        {getFieldDecorator('name')(
                            <Input disabled={true} style={{width: 200}}/>
                        )}
                    </FormItem>
                    <FormItem label="原始密码" labelCol={{span: 8}} wrapperCol={{span: 16}}>
                        {getFieldDecorator('oldPasword',
                            {
                                rules: [{required: true, max: 16, whitespace: true, message: '原始密码不能为空'},
                                    {validator: this.passwordExists}]
                            }
                        )(
                            <Input placeholder="请输入原始密码" autoComplete="off" style={{width: 200}}/>
                        )}
                    </FormItem>
                    <FormItem label="新密码" labelCol={{span: 8}} wrapperCol={{span: 16}}>
                        {getFieldDecorator('password',
                            {
                                rules: [{required: true, whitespace: true, message: '新密码不能为空'},
                                    {validator: this.checkPassword}]
                            }
                        )(
                            <Input placeholder="请输入新密码" autoComplete="off" style={{width: 200}}/>
                        )}
                    </FormItem>
                    <FormItem label="确认密码" labelCol={{span: 8}} wrapperCol={{span: 16}}>
                        {getFieldDecorator('rePassword',
                            {
                                rules: [{required: true, whitespace: true, message: '确认密码不能为空'},
                                    {validator: this.checkRePassword}]
                            }
                        )(
                            <Input placeholder="请输入确认密码" autoComplete="off" style={{width: 200}}/>
                        )}
                    </FormItem>
                </Form>
            </Modal>
        );
    }
}

ChangeUserPasswordForm = createForm({})(ChangeUserPasswordForm);
export default ChangeUserPasswordForm;