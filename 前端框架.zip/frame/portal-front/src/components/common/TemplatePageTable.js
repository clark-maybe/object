import React from 'react';
import {Table} from 'antd';
import {toJS} from 'immutable';

/**
 * 表格模板
 */
class TemplateTable extends React.Component {

    constructor(props) {
        super(props);
        this.setRowClassName = this.setRowClassName.bind(this);
        this.clickRow = this.clickRow.bind(this);
        this.handleChangeCurrentPage = this.handleChangeCurrentPage.bind(this);
        this.state = {
            selectRowRecord: {}
        }
    }

    setRowClassName(record, index) {
        if (record.id === this.state.selectRowRecord.id) {
            return 'table-select-row';
        } else {
            if (index % 2 === 0) {
                return 'table-even-row';
            } else {
                return 'table-odd-row';
            }
        }
    }

    clickRow(record) {
        let {changeSelectLine}=this.props;
        this.setState({
            selectRowRecord: record
        });
        changeSelectLine && changeSelectLine(record);
    }

    handleChangeCurrentPage(pagination) {
        const {query} = this.props;
        query(pagination.current, pagination.pageSize);
    }

    render() {
        const {columns, dataList, title} = this.props;
        let {pagination} = this.props;
        if (!!pagination) {
            pagination = pagination.set('showQuickJumper', true);
            pagination = pagination.set('showSizeChanger', true);
            pagination = pagination.set('showTotal', total => '共' + total + '条');
        }
        return (
            <div>
                <Table  size='small'
                        columns={columns}
                        rowKey={record => record.key}
                        dataSource={!!dataList ? dataList.toJS() : []}
                        title={!!title ? () => title : null}
                        rowClassName={this.setRowClassName}
                        onRowClick={this.clickRow}
                        onChange={this.handleChangeCurrentPage}
                        pagination={!!pagination ? pagination.toJS() : false}
                />
            </div>
        );
    }
}

export default TemplateTable;