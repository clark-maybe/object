/**
 * Created by lwj on 2017/7/4.
 */
import React from 'react'
import {Tag} from 'antd'
const { CheckableTag } = Tag;

export default class UserSelectOne extends React.Component {

    constructor(props){
        super(props);
        this.handleChange = this.handleChange.bind(this);
        const value = this.props.value || '';
        this.state = {value: value}
    }

    componentWillReceiveProps(nextProps){
        if('value' in nextProps && this.props.value !== nextProps.value){
            this.setState({value: nextProps.value});
        }
    }

    handleChange(user){
        const {value} = this.state;
        let changeValue = '';
        if(value == user.get('id')){
            this.setState({ value: '' });
        }else{
            changeValue = user.get('id') + '';
            this.setState({ value: user.get('id') + ''});
        }
        const onChange = this.props.onChange;
        if (onChange) {
            onChange(changeValue);
        }
    }

    render(){
        const {users} = this.props;
        const {value} = this.state;
        return (
            <div>
                {users.map(user => {
                    return (<CheckableTag key={user.get('id') + ''} checked={user.get('id') + '' === value} onChange={this.handleChange.bind(this, user)}>
                        {user.get('name')}
                    </CheckableTag>)
                })}
            </div>
        )
    }

}