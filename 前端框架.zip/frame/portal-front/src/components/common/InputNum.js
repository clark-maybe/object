/**
 * Created by zsp on 2018/4/26.
 */
import React from 'react';
import {Input} from 'antd'
export default class InputNum extends React.Component {
    constructor() {
        super();
        this.state = {
            value: '',
            errorFlag: false
        }
    }

    componentWillMount() {
        let {value} = this.props;
        this.setState({
            value,
            errorFlag: /[^\d]+/g.test(value) || value===""
        });
    }

    componentWillReceiveProps(nextProps) {
        let {value} = nextProps;
        this.setState({
            value,
            errorFlag: /[^\d]+/g.test(value) || value===""
        });
    }

    handleChange = e => {
        let {record, saveChange, dataIndex} = this.props;
        let value = e.target.value;
        saveChange(record, value, dataIndex);
    };

    render() {
        return (
            <div>
                <Input style={{border: this.state.errorFlag ? '1px solid red' : '1px solid #d9d9d9'}}
                       value={this.state.value} onChange={this.handleChange}/>
            </div>
        )
    }
}