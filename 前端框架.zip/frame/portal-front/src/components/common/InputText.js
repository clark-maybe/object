/**
 * Created by zsp on 2018/4/26.
 */
import React from 'react';
import {Input} from 'antd'
export default class InputText extends React.Component {
    constructor() {
        super();
        this.state = {
            errorFlag: false
        }
    }

    componentWillMount() {
        let {value, record} = this.props;
        this.setState({
            errorFlag: /[^\w|\u4e00-\u9fa5]+/g.test(value) || value === "" || record.errorName
        });
    }

    componentWillReceiveProps(nextProps) {
        let {value, record} = nextProps;
        this.setState({
            errorFlag: /[^\w|\u4e00-\u9fa5]+/g.test(value) || value === "" || record.errorName
        });
    }

    handleChange = e => {
        let {record, saveChange, dataIndex} = this.props;
        let value = e.target.value;
        saveChange(record, value, dataIndex);
    };

    render() {
        let {value} = this.props;
        return (
            <div>
                <Input style={{border: this.state.errorFlag ? '1px solid red' : '1px solid #d9d9d9'}}
                       value={value}
                       onChange={this.handleChange}/>
            </div>
        )
    }
}