/**
 * Created by lwj on 2017/5/23.
 */
'use strict'

import React from 'react'
import {Button, Popover} from 'antd'
import { CompactPicker } from 'react-color'

class ColorPicker extends React.Component {

    constructor(props){
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.hide = this.hide.bind(this);
        this.handleVisibleChange = this.handleVisibleChange.bind(this);
        const value = this.props.value || {};

        this.state = {
            visible: false,
            color: value
        }
    }

    componentWillReceiveProps(nextProps) {
        // Should be a controlled component.
        if ('value' in nextProps && this.props.value !== nextProps.value) {
            const value = nextProps.value;
            this.setState({color: value, visible: false});
        }
    }

    hide() {
        this.setState({
            visible: false
        });
    }
    handleVisibleChange(visible) {
        this.setState({ visible });
    }

    handleChange(color){
        this.setState({ color: color.hex, visible: false });
        const onChange = this.props.onChange;
        if (onChange) {
            onChange(color.hex);
        }
    };

    render() {
        const { size } = this.props;
        return (
            <Popover content={<CompactPicker color={ this.state.color } onChange={ this.handleChange }/>}
                     trigger="click"
                     visible={this.state.visible}
                     onVisibleChange={this.handleVisibleChange}
                     title="选择颜色">
                <Button type="dashed" size={size} style={{backgroundColor: this.state.color, width:'100%'}}/>
            </Popover>
        )

    }
}

export default ColorPicker