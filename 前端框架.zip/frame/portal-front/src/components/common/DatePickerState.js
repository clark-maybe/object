/**
 * Created by zsp on 2018/5/17.
 */
import React from 'react';
import {DatePicker} from 'antd'
import moment from 'moment';
export default class DatePickerState extends React.Component {
    constructor() {
        super();
        this.state = {
            value: '',
            errorFlag: false
        }
    }

    disabledDate = value => {
        if (!value) {
            return false;
        }
        return value.format('YYYY-MM-DD') <= moment().format('YYYY-MM-DD');
    };

    handleChange = value => {
        let {record, saveChange, dataIndex} = this.props;
        let dayWeek = value.format('dddd');
        value = value.format('YYYY-MM-DD');
        saveChange(record, value, dataIndex, dayWeek);
    };

    render() {
        let {value} = this.props;
        return (
            <DatePicker disabledDate={this.disabledDate}
                        defaultValue={value ? moment(value, 'YYYY-MM-DD') : null}
                        onChange={this.handleChange}/>
        )
    }
}