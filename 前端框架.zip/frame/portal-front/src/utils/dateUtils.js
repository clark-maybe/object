/**
 * Created by hanzhengqiang on 2017/5/18.
 */
export const DATE_PATTERN = 'yyyyMMdd';
/**
 * 扩展Date的format方法
 * @param format
 * @returns {*}
 */
Date.prototype.format = function (format) {
    var o = {
        'M+': this.getMonth() + 1,
        'd+': this.getDate(),
        'h+': this.getHours(),
        'm+': this.getMinutes(),
        's+': this.getSeconds(),
        'q+': Math.floor((this.getMonth() + 3) / 3),
        'S': this.getMilliseconds()
    }
    if (/(y+)/.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp('(' + k + ')').test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
        }
    }
    return format;
}
export function getDateFormatString(date, fmt) {
    var o = {
        'M+': date.getMonth() + 1, //月份
        'd+': date.getDate(), //日
        'h+': date.getHours() % 12 === 0 ? 12 : date.getHours() % 12, //小时
        'H+': date.getHours(), //小时
        'm+': date.getMinutes(), //分
        's+': date.getSeconds(), //秒
        'q+': Math.floor((date.getMonth() + 3) / 3), //季度
        'S': date.getMilliseconds() //毫秒
    };
    var week = {
        '0': '星期日',
        '1': '星期一',
        '2': '星期二',
        '3': '星期三',
        '4': '星期四',
        '5': '星期五',
        '6': '星期六'
    };
    if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    if (/(E+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, week[date.getDay() + '']);
    }
    for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)));
        }
    }
    return fmt;
}
export function getWeek(date) {
    var week = {
        '0': '星期日',
        '1': '星期一',
        '2': '星期二',
        '3': '星期三',
        '4': '星期四',
        '5': '星期五',
        '6': '星期六'
    };
    return week[date.getDay() + ''];
}


/**
 * 转换字符串为日期对象
 * @param dateStr
 * @param pattern
 * @returns {Date}
 */
export function getDateByString(dateStr, pattern) {
    if ('yyyyMMdd' === pattern) {
        return new Date(dateStr.substring(0, 4), parseInt(dateStr.substring(4, 6)) - 1, dateStr.substring(6, 8));
    } else if ('yyyy-MM-dd' === pattern) {
        return new Date(dateStr.substring(0, 4), parseInt(dateStr.substring(5, 7)) - 1, dateStr.substring(8, 10));
    }
}
/**
 * 是否是当天
 * @param date
 * @returns {boolean}
 */
export function isToday(date) {
    if (date == null) {
        return false;
    }
    var todayStr = getSmpFormatDate(new Date(), false);
    var compStr = getSmpFormatDate(date, false);
    if (todayStr === compStr) {
        return true;
    }
    return false;
}
/**
 * 转换日期对象为日期字符串
 * @param l long值
 * @param pattern 格式字符串,例如：yyyy-MM-dd hh:mm:ss
 * @return 符合要求的日期字符串
 */
export function getFormatDate(date, pattern) {
    if (date === undefined) {
        date = new Date();
    }
    if (pattern === undefined) {
        pattern = 'yyyy-MM-dd hh:mm:ss';
    }
    return date.format(pattern);
}
/**
 * 转换日期对象为日期字符串
 * @param date 日期对象
 * @param isFull 是否为完整的日期数据,
 *               为true时, 格式如'2000-03-05 01:05:04'
 *               为false时, 格式如 '2000-03-05'
 * @return 符合要求的日期字符串
 */
export function getSmpFormatDate(date, isFull) {
    var pattern = '';
    if (isFull || isFull === undefined) {
        pattern = 'yyyy-MM-dd hh:mm';
    } else {
        pattern = 'yyyy-MM-dd';
    }
    return getFormatDate(date, pattern);
}

/**
 * 转换long值为日期字符串
 * @param l long值
 * @param isFull 是否为完整的日期数据,
 *               为true时, 格式如'2000-03-05 01:05:04'
 *               为false时, 格式如 '2000-03-05'
 * @return 符合要求的日期字符串
 */

export function getSmpFormatDateByLong(l, isFull) {
    if (l === 0) {
        return '';
    }
    return getSmpFormatDate(new Date(l), isFull);
}
/**
 * 转换long值为日期字符串
 * @param l long值
 * @param pattern 格式字符串,例如：yyyy-MM-dd hh:mm:ss
 * @return 符合要求的日期字符串
 */

export function getFormatDateByLong(l, pattern) {
    if (l === 0) {
        return '';
    }
    return getFormatDate(new Date(l), pattern);
}
/**
 * 日期的加减
 * @param date
 * @param days
 * @returns {string}
 */
export function addDate(date, days) {
    let a = new Date(date);
    a = a.valueOf();
    a = a + days * 24 * 60 * 60 * 1000;
    a = new Date(a);
    return a;
}

var lastOutputDate;
export function zeroPad(digits, n) {
    n = n.toString();
    while (n.length < digits)
        n = '0' + n;
    return n;
}
export function dateString(date) {
    var currentDate = new Date();
    var gap = Math.abs(currentDate.getTime() - date.getTime());
    var dayGap = Math.floor(gap / 1000 / 60 / 60 / 24);
    var seconds = date.getSeconds().toString();
    var minutes = date.getMinutes().toString();
    var hours = date.getHours().toString();
    if (dayGap === 0) {
        return '今天 ' + zeroPad(2, hours) + ':' + zeroPad(2, minutes) + ':' + zeroPad(2, seconds);
        //timeString(date);
    } else {
        return dayGap + '天前 ' + zeroPad(2, hours) + ':' + zeroPad(2, minutes) + ':' + zeroPad(2, seconds);
    }
}
export function timeString(date) {
    var currentDate = new Date();
    var seconds = date.getSeconds().toString();
    var minutes = date.getMinutes().toString();
    var hours = date.getHours().toString();

    if (!lastOutputDate) {
        lastOutputDate = new Date();
        return zeroPad(2, hours) + ':' + zeroPad(2, minutes) + ':' + zeroPad(2, seconds);
    } else {
        var gap = Math.abs(currentDate.getTime() - lastOutputDate.getTime());
        var minutesGap = gap / 1000 / 60;
        if (minutesGap > 2) {
            lastOutputDate = currentDate;
            return zeroPad(2, hours) + ':' + zeroPad(2, minutes) + ':' + zeroPad(2, seconds);
        } else {
            return '';
        }
    }
}
/**
 * 获取当前月的第一天
 */
export function getCurrentMonthFirst(date) {
    date.setDate(1);
    return date;
}
/**
 * 获取当前月的最后一天
 */
export function getCurrentMonthLast(date) {
    var currentMonth = date.getMonth();
    var nextMonth = ++currentMonth;
    var nextMonthFirstDay = new Date(date.getFullYear(), nextMonth, 1);
    var oneDay = 1000 * 60 * 60 * 24;
    return new Date(nextMonthFirstDay - oneDay);
}

/**
 * 获取开始时间 yyyy-MM-dd 00:00:00
 * @param date
 */
export function getStartDate(date) {
    if (date === undefined) {
        date = new Date();
    }
    var nowStr = getSmpFormatDate(date, false);
    return new Date(nowStr + ' 00:00:00');
}

/**
 * 获取结束时间 yyyy-MM-dd 23:59:59
 * @param date
 */
export function getEndDate(date) {
    if (date === undefined) {
        date = new Date();
    }
    var nowStr = getSmpFormatDate(date, false);
    return new Date(nowStr + ' 23:59:59');
}
/**
 * 将秒数换成时分秒格式
 * 整理：www.jbxue.com
 */

export function formatSeconds(value) {
    if (value === 0) {
        return '0秒';
    }
    var theTime = parseInt(value);// 秒
    var theTime1 = 0;// 分
    var theTime2 = 0;// 小时
    if (theTime > 60) {
        theTime1 = parseInt(theTime / 60);
        theTime = parseInt(theTime % 60);
        if (theTime1 > 60) {
            theTime2 = parseInt(theTime1 / 60);
            theTime1 = parseInt(theTime1 % 60);
        }
    }
    var result = "" + parseInt(theTime) + "秒";
    if (theTime1 > 0) {
        result = "" + parseInt(theTime1) + "分" + result;
    }
    if (theTime2 > 0) {
        result = "" + parseInt(theTime2) + "小时" + result;
    }
    return result;
}
/**
 * 根据日期计算年龄
 * @param str
 * @returns {*}
 */
export function getAgeByBirthday(str) {
    if (!str) {
        return '';
    }
    var r = str.match(/^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})$/);
    if (r === null) {
        return str;
    }
    var d = new Date(r[1], r[3] - 1, r[4]);
    if (d.getFullYear() === r[1] && (d.getMonth() + 1) === r[3] && d.getDate() === r[4]) {
        var Y = new Date().getFullYear();
        return (Y - r[1]);
    }
    return '';
}
/*
 * 将日期字符串加-或/
 * 如: `20180918`=> 2018-09-18
 * */
export function convertDateStr(str, pattern) {
    if (!pattern) {
        pattern = '-';
    }
    if (!str) {
        return getFormatDate(new Date(),`yyyy${pattern}MM${pattern}dd`);
    }
    return str.replace(/(\d{4})(\d{2})(\d{2})/, `$1${pattern}$2${pattern}$3`);
}

