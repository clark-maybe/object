/**
 * Created by lwj on 2017/7/4.
 */
import {getWeek} from './dateUtils'
import moment from 'moment'

it('get week by data', () => {
   expect(getWeek(moment('2017-07-04', 'YYYY-MM-DD').toDate())).toBe('星期二');
});