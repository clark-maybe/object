/**
 * Created by hanzhengqiang on 16/8/4.
 */

/**
 * 校验手机号电话号码
 * @param rule
 * @param value
 * @param callback
 */
export function checkMobileUtils(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^((1[3|4|5|6|7|8|9]\d{9})|((\d{7,8})|(\d{4}|\d{3})(-?)(\d{7,8})|(\d{4}|\d{3})(-?)(\d{7,8})(-?)(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})(-?)(\d{4}|\d{3}|\d{2}|\d{1})))$/.test(value))) {
            callback(new Error('电话格式不正确'));
        } else {
            callback();
        }
    }
}

export function checkPhone(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^((13\d|14\d|15[^4\D]|17\d|18\d)\d{8}$|170[^346\D]\d{7}$)|(^(0[0-9]{2,3})([1-9][0-9]{6,7})$|^[1-9][0-9]{6,7}$|^[\+]?\d{1,19}$)/.test(value))) {
            callback(new Error('电话格式不正确'));
        } else {
            callback();
        }
    }
}

export function checkSmsPhone(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^1(3|4|5|7|8)[0-9]\d{8}$/.test(value))) {
            callback(new Error('手机不正确'));
        } else {
            callback();
        }
    }
}

export function checkEmail(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value))) {
            callback(new Error('邮箱格式不正确'));
        } else {
            callback();
        }
    }
}


export function checkName(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^[a-zA-Z0-9-\.\u4e00-\u9fa5]+$/.test(value))) {
            callback(new Error('名称只允许汉字、数字、字母以及-.'));
        } else {
            callback();
        }
    }
}
export function checkRemark(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if ((/[<>]|(script)|(div)/).test(value)) {
            callback(new Error('输入内容包含特殊字符'));
        } else {
            callback();
        }
    }
}
export function checkPersonName(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^[a-zA-Z\u4e00-\u9fa50-9]+$/.test(value))) {
            callback(new Error('姓名只允许汉字、字母、数字'));
        } else {
            callback();
        }
    }
}
export function checkAccount(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^[a-zA-Z0-9-@.\u4e00-\u9fa5]+$/.test(value))) {
            callback(new Error('姓名只允许汉字、字母、数字及字符- @ .'));
        } else {
            callback();
        }
    }
}
export function checkQq(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^[1-9][0-9]{4,10}$/.test(value))) {
            callback(new Error('QQ号码不合法'));
        } else {
            callback();
        }
    }
}
/**
 * 校验URL
 * @param rule
 * @param value
 * @param callback
 */
export function checkUrlUtils(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^(http|https):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(value))) {
            callback(new Error('URL格式不正确'));
        } else {
            callback();
        }
    }
}

export function checkSpecialcharUtils(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/[`~!@#$^&*()=|{}':;',\[\].<>\/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]|(script)|(div)/).test(value)) {
            callback(new Error('输入内容包含特殊字符'));
        } else {
            callback();
        }
    }
}
/**
 * 校验金额
 * @param rule
 * @param value
 * @param callback
 */
export function checkPrice(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^\d+((\.\d{1,2}))?$/.test(value))) {
            callback(new Error('请输入正确的金额,最多保留两位小数'));
        } else {
            if (value == 0) {
                callback(new Error('金额必须大于0'));
            } else {
                callback();
            }
        }
    }
}
/**
 * 校验余额
 * @param rule
 * @param value
 * @param callback
 */
export function checkOwePrice(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^\d+((\.\d{1,2}))?$/.test(value))) {
            callback(new Error('请输入正确的金额,最多保留两位小数'));
        } else {
            callback();
        }
    }
}

/**
 * 校验Ip
 * @param rule
 * @param value
 * @param callback
 */
export function checkIp(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})?$/.test(value))) {
            callback(new Error('请输入正确的IP地址'));
        } else {
            callback();
        }
    }
}
/**
 * 校验正整数
 * @param rule
 * @param value
 * @param callback
 */
export function checkInteger(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^\d+$/.test(value))) {
            callback(new Error('请输入正确的数值'));
        } else {
            callback();
        }
    }
}
/**
 * 校验整数
 * @param rule
 * @param value
 * @param callback
 */
export function checkDiscountCount(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^((-1)|\d+)$/.test(value))) {
            callback(new Error('请输入正确的次数'));
        } else {
            callback();
        }
    }
}
/**
 * 校验折扣0-1，两位小数
 * @param rule
 * @param value
 * @param callback
 */
export function checkDiscount(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (!(/^([1](.[0]{1,2})?|([0](.[0-9]{1,2})?))$/).test(value)) {
            callback(new Error('格式错误!'));
        } else {
            callback();
        }
    }
}

/**
 * 校验持续单元
 * @param rule
 * @param value
 * @param callback
 */
export function checkTimeUnitRange(rule, value, callback) {
    if (!value) {
        callback();
    } else {
        if (value <= 0 || value > 50) {
            callback(new Error('请输入正确的数值(1-50)'));
        } else {
            callback();
        }
    }
}
/**
 * 减法
 * @param arg1
 * @param arg2
 * @returns {string}
 */
export function floatSubtraction(arg1, arg2) {
    var r1, r2, m, n;
    try {
        r1 = arg1.toString().split(".")[1].length
    } catch (e) {
        r1 = 0
    }
    try {
        r2 = arg2.toString().split(".")[1].length
    } catch (e) {
        r2 = 0
    }
    m = Math.pow(10, Math.max(r1, r2));
    n = (r1 >= r2) ? r1 : r2;
    return parseFloat(((arg1 * m - arg2 * m) / m).toFixed(n));
}