/**
 * Created by hanzhengqiang on 2017/5/18.
 */
/**
 * 排序
 * @param list
 */
export function getSortDataLists(list, sortColums, orderBy, sortType) {
    return list.sort(function (a, b) {
        if (sortType !== 'undefined' && sortType == 'String') {
            var param1, param2;
            if (sortColums.indexOf('.') == -1) {
                param1 = a[sortColums];
                param2 = b[sortColums];
            } else {
                var temp = sortColums.split('.');
                param1 = a[temp[0]] ? a[temp[0]][temp[1]] : null;
                param2 = b[temp[0]] ? b[temp[0]][temp[1]] : null;
            }
            if (param1 == null) {
                if (orderBy == 'desc' || orderBy == 'descend') {
                    return 1;
                } else {
                    return -1;
                }
            } else if (param2 == null) {
                if (orderBy == 'desc' || orderBy == 'descend') {
                    return -1;
                } else {
                    return 1;
                }
            } else {
                if (orderBy == 'desc' || orderBy == 'descend') {
                    return param1.localeCompare(param2);
                } else {
                    return param2.localeCompare(param1);
                }
            }
        } else if (sortType !== 'undefined' && sortType == 'Date') {
            var param1, param2;
            if (sortColums.indexOf('.') == -1) {
                param1 = a[sortColums];
                param2 = b[sortColums];
            } else {
                var temp = sortColums.split('.');
                param1 = a[temp[0]] ? a[temp[0]][temp[1]] : null;
                param2 = b[temp[0]] ? b[temp[0]][temp[1]] : null;
            }
            if (param1 == null) {
                if (orderBy == 'desc' || orderBy == 'descend') {
                    return -1;
                } else {
                    return 1;
                }
            } else if (param2 == null) {
                if (orderBy == 'desc' || orderBy == 'descend') {
                    return 1;
                } else {
                    return -1;
                }
            } else {
                if (orderBy == 'desc' || orderBy == 'descend') {
                    return param2.localeCompare(param1);
                } else {
                    return param1.localeCompare(param2);
                }
            }
        } else if (sortType !== 'undefined' && sortType === 'Number') {
            let aValue = !!a[sortColums] ? a[sortColums] : 0;
            let bValue = !!b[sortColums] ? b[sortColums] : 0;
            if(orderBy === 'desc'|| orderBy === 'descend'){
                return bValue-aValue;
            }else{
                return aValue-bValue;
            }
        } else {
            let aValue = !!a[sortColums] ? a[sortColums] : 0;
            let bValue = !!b[sortColums] ? b[sortColums] : 0;
            if (orderBy == 'desc' || orderBy == 'descend') {
                return bValue - aValue
            } else {
                return aValue - bValue
            }
        }
    });
}
