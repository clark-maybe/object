/**
 * Created by lwj on 2016/6/20.
 */
import { Modal, notification } from 'antd'
import history from '../history'
import {loadingFlag} from '../actions/portalMainAction'

const DEFAULT_FETCH_OPTIONS = {
    credentials: 'include',
    method: 'POST',
    headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }
};

var count = 0;

const mergeOptions = (tOptions, sOptions) =>{
    let options = {};
    for(let att in tOptions){
        options[att] = tOptions[att];
    }
    for(let att in sOptions){
        options[att] = sOptions[att];
    }
    return options;
};

export function fetchData(url, options, dispatch){

    let finalOptions = DEFAULT_FETCH_OPTIONS;
    if(!!options){
        finalOptions = mergeOptions(DEFAULT_FETCH_OPTIONS, options);
    }
    return fetch(url, finalOptions)
        .then(checkStatus)
        .then(parseJSON).catch(function(e){
            if(count > 0){
                if(count === 1){
                    Modal.error({
                        title:'请求失败',
                        content:'其他地方登录或者登录超时，请重新登录',
                        onOk() {
                            history.replace('/');
                        }
                    });
                }
                return;
            }
            if(count === 0){
                notification.error({
                    placement: 'bottomLeft',
                    message: '数据查询',
                    description: '网络通信失败!',
                    className: 'notification-failed'
                });
            }
            if(!!dispatch){
                dispatch(loadingFlag(false));
            }
    });
}

function checkStatus(response){
    if(response.ok){
        count = 0;
       return response;
    }else{
        if(response.status === 401){
            count += 1;
        }
        var error = new Error(response.statusText);
        error.response = response;
        throw error;
    }
}

function parseJSON(response){
    return response.json();
}
