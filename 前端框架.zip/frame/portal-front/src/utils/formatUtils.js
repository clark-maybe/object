/**
 * Created by hanzhengqiang on 2017/5/18.
 */
/**
 * 格式化金额
 * @param s
 * @param n
 * @returns {string}
 */
export function formatMoney(s, n) {
    n = n > 0 && n <= 20 ? n : 2;
    s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";
    var l = s.split(".")[0].split("").reverse(),
        r = s.split(".")[1];
    var t = "";
    for (var i = 0; i < l.length; i++) {
        t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : "");
    }
    return t.split("").reverse().join("") + "." + r;
}

export function formatLongMoney(s) {
    let n = 0;
    s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";
    var l = s.split(".")[0].split("").reverse();
    var t = "";
    for (var i = 0; i < l.length; i++) {
        t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : "");
    }
    return t.split("").reverse().join("");
}
/**
 * 格式化手机号,隐藏中间四位
 * @param value
 */
export function formatPhone(value) {
    if (!value) {
        return '';
    }
    if (value.length < 11) {
        return value.substr(0, 2) + '****' + value.substr(6, 2);
    } else if (value.length == 11) {
        return value.substr(0, 3) + '****' + value.substr(7, 4);
    } else {
        return value.substr(1, 3) + '****' + value.substr(8, 4);
    }
}