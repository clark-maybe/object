/**
 * Created by hanzhengqiang on 2017/5/18.
 */
import {fromJS} from 'immutable'
import {Modal} from 'antd';
import moment from 'moment'
import {getSmpFormatDateByLong} from '../utils/dateUtils'

/**
 * 导出
 * @param exportColumns --导出文件列头
 * @param exportDataList --导出数据
 * @param exportFileName --导出文件名称
 * @param noDataWarnTitleName -- 没有导出数据提示语
 * @param exportDateStr -- 导出时间
 */
export function exportData(exportColumns, exportDataList, exportFileName, noDataWarnTitleName, exportDateStr) {
    if (exportDataList.size === 0) {
        Modal.warning({
            title: !!noDataWarnTitleName ? noDataWarnTitleName : '请查询导出数据',
            onOk() {
            }
        });
    } else {
        let mystyle = {
            headers: false
        };
        let tempObj = {};
        let tempTh = [];
        exportColumns.toJS().map(function (column) {
            if (!column.children || column.children.length === 0) {
                tempObj[column['dataIndex']] = column['title'];
                tempTh.push(column['dataIndex']);
            } else {
                let firstTitle = column['title'];
                column.children.map(function (firstChildColumns) {
                    if (!firstChildColumns.children || firstChildColumns.children.length === 0) {
                        tempObj[firstChildColumns['dataIndex']] = firstTitle + '-' + firstChildColumns['title'];
                        tempTh.push(firstChildColumns['dataIndex']);
                    } else {
                        let secondTitle = firstChildColumns['title'];
                        firstChildColumns.children.map(function (secondChildColumns) {
                            if (!secondChildColumns.children || secondChildColumns.children.length === 0) {
                                tempObj[secondChildColumns['dataIndex']] = firstTitle + '-' + secondTitle + '-' + secondChildColumns['title'];
                                tempTh.push(secondChildColumns['dataIndex']);
                            } else {
                                Modal.warning({
                                    title: '数据导出暂时只支持三级表头，请联系管理员！',
                                    onOk() {
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });
        let tempList = exportDataList.unshift(fromJS(tempObj));
        //不支持中文名称的别名
        if (!exportDateStr) {
            exportDateStr = moment().format('YYYYMMDD');
        }
        tempList = tempList.toJS().map(item => {
            for (let key in item) {
                if (typeof item[key] === 'number' && /(^\d{12,}$)/.test(item[key])) {
                    item[key] = getSmpFormatDateByLong(item[key], false);
                }
            }
            return item;
        });
        alasql('SELECT ' + tempTh.join() + ' INTO XLSX("' + exportFileName + '_' + exportDateStr + '.xlsx",?) FROM ?', [mystyle, tempList]);
    }
}