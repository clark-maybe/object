/**
 * Created by lwj on 2017/5/15.
 */
import createBrowserHistory  from 'history/createBrowserHistory'
import {Modal} from 'antd'

export default createBrowserHistory({
    getUserConfirmation(message, callback) {
        Modal.confirm({
            title: '确认要离开吗',
            content: message,
            onOk() {
                callback(true);
            },
            onCancel() {
                callback(false);
            }
        })
    }
})